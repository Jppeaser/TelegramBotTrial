package com.solera.crucedebanderas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelegramBotSoleraApplicationTests {

	@Test
	void contextLoads() {
	}

}
